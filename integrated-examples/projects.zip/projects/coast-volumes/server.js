const http = require("http");
const { Pool } = require("pg");
const { createClient } = require("redis");

const PORT = 3000;

const pgPool = new Pool({ connectionString: process.env.DATABASE_URL });
const redisClient = createClient({ url: process.env.REDIS_URL });

async function ensureTable() {
  await pgPool.query(`
    CREATE TABLE IF NOT EXISTS vol_test (
      id SERIAL PRIMARY KEY,
      label TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
}

async function init() {
  await redisClient.connect();
  await ensureTable();
  console.log("Connected to Postgres and Redis.");
}

const server = http.createServer(async (req, res) => {
  const json = (data, status = 200) => {
    res.writeHead(status, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  try {
    if (req.url === "/health") {
      return json({ status: "ok" });
    }

    if (req.url === "/db-check") {
      const r = await pgPool.query("SELECT 1 AS ok");
      return json({ db: "connected", result: r.rows[0] });
    }

    if (req.url === "/cache-check") {
      await redisClient.set("coast_test", "ok");
      const val = await redisClient.get("coast_test");
      return json({ cache: "connected", value: val });
    }

    if (req.url === "/db-write") {
      await ensureTable();
      const label = `entry-${Date.now()}`;
      const r = await pgPool.query(
        "INSERT INTO vol_test (label) VALUES ($1) RETURNING *",
        [label]
      );
      return json({ written: r.rows[0] }, 201);
    }

    if (req.url === "/db-read") {
      const r = await pgPool.query("SELECT * FROM vol_test ORDER BY id");
      return json({ rows: r.rows, count: r.rows.length });
    }

    return json({ message: "coast-volumes test app", branch: "main" });
  } catch (err) {
    console.error("Request error:", err);
    json({ error: err.message }, 500);
  }
});

init()
  .then(() => {
    server.listen(PORT, () => console.log(`coast-volumes listening on :${PORT}`));
  })
  .catch((err) => {
    console.error("Failed to start:", err);
    process.exit(1);
  });
