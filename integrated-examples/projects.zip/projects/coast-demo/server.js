const http = require("http");
const { Pool } = require("pg");
const { createClient } = require("redis");

const PORT = 3000;

const pgPool = new Pool({ connectionString: process.env.DATABASE_URL });
const redisClient = createClient({ url: process.env.REDIS_URL });

async function migrate() {
  await pgPool.query(`
    CREATE TABLE IF NOT EXISTS products (
      id SERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
}

async function init() {
  await redisClient.connect();
  await migrate();
  console.log("Migrations complete. Connected to Postgres and Redis.");
}

const server = http.createServer(async (req, res) => {
  const json = (data, status = 200) => {
    res.writeHead(status, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  try {
    if (req.url === "/health") {
      return json({ status: "ok" });
    }

    if (req.url === "/products" && req.method === "POST") {
      let body = "";
      for await (const chunk of req) body += chunk;
      const { name } = JSON.parse(body);
      const result = await pgPool.query(
        "INSERT INTO products (name) VALUES ($1) RETURNING *",
        [name]
      );
      return json({ product: result.rows[0] }, 201);
    }

    if (req.url === "/products") {
      const result = await pgPool.query("SELECT * FROM products ORDER BY id");
      return json({ products: result.rows });
    }

    if (req.url === "/tables") {
      const result = await pgPool.query(`
        SELECT table_name FROM information_schema.tables
        WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
        ORDER BY table_name
      `);
      return json({ tables: result.rows.map((r) => r.table_name) });
    }

    if (req.url === "/redis-info") {
      const marker = await redisClient.get("instance_marker");
      const counter = await redisClient.get("hit_counter");
      return json({
        instance_marker: marker,
        hit_counter: counter ? parseInt(counter) : 0,
      });
    }

    if (req.url === "/redis-set-marker") {
      await redisClient.set("instance_marker", "main");
      const count = await redisClient.incr("hit_counter");
      return json({ marker: "main", hit_counter: count });
    }

    // Default: homepage
    const count = await redisClient.incr("hit_counter");
    const pgResult = await pgPool.query("SELECT COUNT(*) FROM products");
    return json({
      message: "Hello from Coast!",
      branch: "main",
      redis_hits: count,
      product_count: parseInt(pgResult.rows[0].count),
    });
  } catch (err) {
    console.error("Request error:", err);
    json({ error: err.message }, 500);
  }
});

init()
  .then(() => {
    server.listen(PORT, () => {
      console.log(`Coast demo listening on :${PORT}`);
    });
  })
  .catch((err) => {
    console.error("Failed to start:", err);
    process.exit(1);
  });
