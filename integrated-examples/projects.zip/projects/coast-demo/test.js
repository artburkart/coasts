// Coast-demo branch tests (main branch).
//
// Tests the products table (postgres) and redis isolation.
// Each branch has its own version of this file with branch-specific tests.
//
// Run inside the app container:
//   docker compose exec -T app node test.js

const { Pool } = require("pg");
const { createClient } = require("redis");

const pgPool = new Pool({ connectionString: process.env.DATABASE_URL });
const redisClient = createClient({ url: process.env.REDIS_URL });

let passed = 0;
let failed = 0;

function assert(condition, msg) {
  if (condition) {
    console.log(`  PASS: ${msg}`);
    passed++;
  } else {
    console.log(`  FAIL: ${msg}`);
    failed++;
  }
}

async function run() {
  await redisClient.connect();

  console.log("=== Main branch tests ===");
  console.log("");

  // --- Postgres: table existence ---
  const tables = await pgPool.query(`
    SELECT table_name FROM information_schema.tables
    WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
    ORDER BY table_name
  `);
  const tableNames = tables.rows.map((r) => r.table_name);
  assert(tableNames.includes("products"), "products table exists");
  assert(!tableNames.includes("users"), "users table does NOT exist on main");
  assert(!tableNames.includes("orders"), "orders table does NOT exist on main");

  // --- Postgres: CRUD on products ---
  await pgPool.query("DELETE FROM products WHERE name = '__test_widget__'");
  const ins = await pgPool.query(
    "INSERT INTO products (name) VALUES ('__test_widget__') RETURNING *"
  );
  assert(ins.rows.length === 1, "inserted test product");
  assert(ins.rows[0].name === "__test_widget__", "product name correct");

  const sel = await pgPool.query(
    "SELECT * FROM products WHERE name = '__test_widget__'"
  );
  assert(sel.rows.length === 1, "queried test product");

  const del = await pgPool.query(
    "DELETE FROM products WHERE name = '__test_widget__'"
  );
  assert(del.rowCount === 1, "deleted test product");

  // --- Redis: write/read ---
  await redisClient.set("__test_key__", "hello_from_main");
  const val = await redisClient.get("__test_key__");
  assert(val === "hello_from_main", "redis write/read works");
  await redisClient.del("__test_key__");

  // --- Redis: isolation check ---
  const marker = await redisClient.get("instance_marker");
  assert(
    marker === null || marker === "main",
    "redis has no foreign instance marker (isolated)"
  );

  // --- Cleanup ---
  await redisClient.quit();
  await pgPool.end();

  console.log("");
  console.log(`${passed} passed, ${failed} failed`);
  process.exit(failed > 0 ? 1 : 0);
}

run().catch((err) => {
  console.error("Test error:", err);
  process.exit(1);
});
