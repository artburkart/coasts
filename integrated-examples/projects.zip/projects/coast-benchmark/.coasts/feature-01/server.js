const http = require("http");

const server = http.createServer((req, res) => {
  const json = (data) => {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(data));
  };

  if (req.url === "/health") return json({ status: "ok" });
  return json({ service: "coast-benchmark", feature: "feature-01" });
});

server.listen(3000, () => console.log("Benchmark server on :3000"));
